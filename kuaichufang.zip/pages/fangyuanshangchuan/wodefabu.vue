<template>
	<view>
		<image src="../../static/wodefabu.png" style="width:100%;" mode="widthFix"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
